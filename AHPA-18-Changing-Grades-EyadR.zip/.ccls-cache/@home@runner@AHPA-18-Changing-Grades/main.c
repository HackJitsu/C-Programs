/*
 * AHPA #18: Changing Grades
 *
 * Create a C function (switcher) that
 * will receive a pointer to the 
 * finalExams array, using only 
 * pointers look for D scores and boost 
 * them to C scores.
 *
 */

#include <stdio.h>

void switcher() {
  
}

int main(void) {
  
  int finalExams[] = {90,82,65,79,67,82,94,64,88,78,92,61,96,83,74};
  
  return 0;
}