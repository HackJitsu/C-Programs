/*
 * AHPA #18: Changing Grades
 *
 * Create a C function (switcher) that
 * will receive a pointer to the 
 * finalExams array, using only 
 * pointers look for D scores and boost 
 * them to C scores.
 *
 */

#include <stdio.h>
#include <string.h>

void printA(int array[], int arraySize){

  for(int i=0; i<arraySize; ++i){
    printf("%d ", array[i]);
  }
    printf("\n");
  
}


void switcher(int* array, int arraySize){
  int i;
  int counter = 0;
  
  while (counter < arraySize){

    if(*array < 70){
       *array += (70 - *array); 
      }
    ++counter;
    ++array;
    }
  }

int main(void) {
  
  int finalExams[] = {90,82,65,79,67,82,94,64,88,78,92,61,96,83,74};
  int arraySize = sizeof(finalExams) / sizeof(finalExams[0]);

  printf("Scores before boosting\n");
  printA(finalExams, arraySize);

  switcher(finalExams, arraySize);

  printf("\nScores after being boosted\n");
  printA(finalExams, arraySize);
  
  return 0;
}