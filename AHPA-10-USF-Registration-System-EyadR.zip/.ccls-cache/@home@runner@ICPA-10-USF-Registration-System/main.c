/*
 * ICPA #10: USF Registration System
 *
 * Create a program that will allow 
 * data that describes a USF class 
 * to be entered: course number, 
 * course name, credits, teacher 
 * name.
 *
 * Create a structure to hold this, 
 * make it part of an array that 
 * can hold 100 classes, and print 
 * it out after it has been loaded.
 */


#include <stdio.h>
#define maxNumClasses 100

int main(void) {
  
  return 0;
}