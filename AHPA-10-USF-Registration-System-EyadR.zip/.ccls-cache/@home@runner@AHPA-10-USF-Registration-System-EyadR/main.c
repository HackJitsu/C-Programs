/*
 * ICPA #10: USF Registration System
 *
 * Create a program that will allow 
 * data that describes a USF class 
 * to be entered: course number, 
 * course name, credits, teacher 
 * name.
 *
 * Create a structure to hold this, 
 * make it part of an array that 
 * can hold 100 classes, and print 
 * it out after it has been loaded.
 */


#include <stdio.h>
#define maxNumClasses 100

  struct classDescription{
  int courseNum;
  char courseName[60];
  int credits;
  char teacherName[60];
  };

int main(void) {
 // int total = 100;
  int class;
  struct classDescription usfClass[maxNumClasses];
  
  //taking info by looping
  for (int i = 0; i < maxNumClasses; i++){
    printf("To go on with registration press 1 or to exit press 2: ");
    
    int toRegistration;
    scanf("%i", &toRegistration);

    if(toRegistration == 1){
        class++;
          
    printf("Enter course number: ");
    scanf("%d", &usfClass[i].courseNum);

    printf("Enter course name: ");
    scanf("%s", usfClass[i].courseName);

    printf("Enter amount of credits: ");
    scanf("%d", &usfClass[i].credits);
  
    printf("Enter teacher last name: ");
    scanf("%s", usfClass[i].teacherName);

    printf("\n");
    }
    else {
      printf("Exiting registraton system now \n");
      break;
    }
  }
  //looping to display info
  for(int i = 0; i < class; i++){
    printf("\n The details of class %d", i+1);
    printf("\n Course Number: %d", usfClass[i].courseNum);
    printf("\n Course Name: %s", usfClass[i].courseName);
    printf("\n Amount of credits: %d", usfClass[i].credits);
    printf("\n Teacher name: %s", usfClass[i].teacherName);
    printf("\n");
  }       
  return 0;
}