/*
 * AHPA #5: The C ATM Machine
 */

#include <stdio.h>

int main(void) {
  
  return 0;
}