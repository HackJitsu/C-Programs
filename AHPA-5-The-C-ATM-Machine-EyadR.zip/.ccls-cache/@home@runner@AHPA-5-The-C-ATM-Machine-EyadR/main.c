/*
 * AHPA #5: The C ATM Machine
 */

#include <stdio.h>

int main(void) {
  printf("Enter withdraw amount: ");
  int withdrawAmount;
  
  scanf("%d", &withdrawAmount);
  
  if(withdrawAmount == 200){
    printf("$100 $100");
  }
  if(withdrawAmount == 0){
    printf("Nothing withdrew");
  } 
  if(withdrawAmount > 200){
    printf("Error");
    }
  while (withdrawAmount < 200 && withdrawAmount>=100){    
      printf("$100");
     withdrawAmount -=100;    
   }
  while (withdrawAmount < 100 && withdrawAmount >= 50){
    printf("$50");
    withdrawAmount -= 50;
  }
  while (withdrawAmount < 50 && withdrawAmount >= 20){
    printf("$20");
    withdrawAmount -= 20;
  } 
  while(withdrawAmount <20 && withdrawAmount >= 10){
    printf("$10");
    withdrawAmount -= 10;
    }
  while(withdrawAmount < 10 && withdrawAmount >= 5){
    printf("$5");
    withdrawAmount -= 5;
  }
    while(withdrawAmount < 5 && withdrawAmount >= 1){
    printf("$1");
    withdrawAmount -= 1;
    }  
}
