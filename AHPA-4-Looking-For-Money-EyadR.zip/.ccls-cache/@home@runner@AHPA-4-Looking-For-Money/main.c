/*
  Have the user enter a line of input.
Scan the line of input using getchar looking for a numerical dollar amount.
Print out each dollar amount that you find on the line.
  */

#include <stdio.h>

int main(void) {
  printf("Hello World\n");
  return 0;
}