/*
 * AHPA #8: Password Hashing
 *
 * Ask the user to enter their 
 * password.
 *
 * Convert the password to all 
 * upper case.
 *
 * Convert each letter in the 
 * password to its ASCII value.
 *
 * Add 25 to each letter's ASCII 
 * value - if the number becomes 
 * greater than 90 then have it 
 * wrap around to 65 (e.g. a number 
 * that became 92 would become 66).
 *
 * Convert the new ASCII values 
 * back into text and print them.
 * 
 * Have the user enter a password 
 * to decode.
 * 
 * Show that the decoded password 
 * is the original password entered 
 * by the user.
 */

#include <stdio.h>
#include <ctype.h>
#include <string.h>

int main() {
  char password[40];
  int i;
  printf("Please enter your password: \n");
    scanf("%s", password);
    for (i = 0; i < strlen(password); i++){
      password[i] = toupper(password[i]);
    }
    printf("%s\n", password);
  
    for (i = 0; i < strlen(password); i++){
      password[i] = password[i] + 25;

      if (password[i] > 'Z'){
        password[i] = password[i] - 26;
      }
    }
      printf("Your encoded password is %s \n", password);
    
      printf("Please enter a passcode to decode: ");
      scanf("%s", password);
  
      for (i = 0; i < strlen(password); i++){
      password[i] = password[i] - 25;

      if (password[i] < 'A'){
        password[i] = password[i] + 26;
      }
    }
      printf("Your decoded password is %s \n", password);
  
 }