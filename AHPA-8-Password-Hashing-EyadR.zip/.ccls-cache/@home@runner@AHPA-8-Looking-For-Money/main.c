/*
 * AHPA #8: Password Hashing
 *
 * Ask the user to enter their 
 * password.
 *
 * Convert the password to all 
 * upper case.
 *
 * Convert each letter in the 
 * password to its ASCII value.
 *
 * Add 25 to each letter's ASCII 
 * value - if the number becomes 
 * greater than 90 then have it 
 * wrap around to 65 (e.g. a number 
 * that became 92 would become 66).
 *
 * Convert the new ASCII values 
 * back into text and print them.
 * 
 * Have the user enter a password 
 * to decode.
 * 
 * Show that the decoded password 
 * is the original password entered 
 * by the user.
 */

#include <stdio.h>

int main(void) {
  
  return 0;
}