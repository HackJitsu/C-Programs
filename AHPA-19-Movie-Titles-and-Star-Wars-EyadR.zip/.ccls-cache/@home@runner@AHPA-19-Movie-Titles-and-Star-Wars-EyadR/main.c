/*
 * AHPA #19: Movie Titles & Star Wars
 *
 * From a data file ("Lesson 14 - 
 * Movie Data"), read in data for Year, 
 * Total Gross, %± LY, Releases, 
 * Average, #1 Release for the years 
 * 1977 to 2019.
 *
 * I have decided that longer movie 
 * titles make more money. Add up the 
 * average income for each movie length 
 * and then print it out.
 * 
 * 
 * Tell me which movie length made the 
 * most money.
 * 
 * Create an array that uses pointers 
 * to store each of the Star Wars movie 
 * titles. Once created, print out all 
 * of the movie titles in the array.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LEN 1000
#define maxTitleSize 100
#define MaxStarWarsMovies 10

int main() {
  int avgPerLength[maxTitleSize];

  for(int i = 0; i < maxTitleSize; ++i)
    avgPerLength[i] = 0.0;
    

  char starWarsMovieTitles[MaxStarWarsMovies][maxTitleSize];
  int starWarsMovieCount = 0;

  FILE* movieReleases = fopen("Lesson 14 - Movie Data.txt", "r");

  if(movieReleases == NULL){
    printf("Failed to open file");
    return 0;
    }

  char str[MAX_LEN];
  int year, releases, average;
  float total;
  char title[maxTitleSize];
  
  while (fgets (str, MAX_LEN, movieReleases ) != NULL ) {
        sscanf(str,"%d %f %d %d %[^\n]s",&year,&total,&releases,&average,title);

        int length = strlen(title);
        avgPerLength[length] += average;

      if (strstr(title, "Star Wars") != NULL)
        strcpy(starWarsMovieTitles[starWarsMovieCount++], title);        
    }
  
    int maxIndex = 0;
    printf("%-10s%-10s\n", "length", "average");
    for(int i = 0; i < maxTitleSize; ++i){
      if (avgPerLength[i] > 0)
        printf("%-10d%-10d\n", i, avgPerLength[i]);
      if(avgPerLength[i] > avgPerLength[maxIndex])
        maxIndex = i;
    }
    printf("\nMovie length %d made the most money %d\n", maxIndex, avgPerLength[maxIndex]);

    printf("\nStar Wars Movie Titles: \n");

    for(int i=0; i < starWarsMovieCount; ++i)
      printf("%s\n", starWarsMovieTitles[i]);
  }