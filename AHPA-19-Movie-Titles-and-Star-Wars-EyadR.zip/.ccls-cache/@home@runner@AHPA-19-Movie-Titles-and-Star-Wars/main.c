/*
 * AHPA #19: Movie Titles & Star Wars
 *
 * From a data file ("Lesson 14 - 
 * Movie Data"), read in data for Year, 
 * Total Gross, %± LY, Releases, 
 * Average, #1 Release for the years 
 * 1977 to 2019.
 *
 * I have decided that longer movie 
 * titles make more money. Add up the 
 * average income for each movie length 
 * and then print it out.
 * 
 * 
 * Tell me which movie length made the 
 * most money.
 * 
 * Create an array that uses pointers 
 * to store each of the Star Wars movie 
 * titles. Once created, print out all 
 * of the movie titles in the array.
 *
 */

#include <stdio.h>

int main(void) {
  
  while (fgets (str, MAX_LEN, movieReleases ) != NULL ) {
        sscanf(str,"%d %f %d %d %[^\n]s",&year,&total,&releases,&average,&title);

  return 0;
}