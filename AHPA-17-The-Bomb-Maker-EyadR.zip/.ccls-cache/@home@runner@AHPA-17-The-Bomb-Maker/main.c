/*
 * AHPA #17: The Bomb Maker  
 *
 * The program will use a function
 * called "makeCounter" to create 
 * the countdown list.
 *
 * The function will accept a 
 * pointer to the array that will 
 * contain the 1-10 or 10-1 count, 
 * two pointers to the words 
 * "countdown" and "countup", and a 
 * flag to indicate if a countdown 
 * or a countup is to be created.
 *
 * Create a routine that will place 
 * the count into the passed array 
 * and then return a pointer to the 
 * word that describes the type of 
 * countdown / countup that has 
 * been created based on the 
 * variable flag 
 * (true = countdown, false = 
 * countup).
*/ 

#include <stdio.h>
#include <stdbool.h>

char *makeCounter(int *countHolder, char *downCount, char *upCount, bool flag);

int main(void) {
  
  return 0;
}