/*
 * AHPA #17: The Bomb Maker  
 *
 * The program will use a function
 * called "makeCounter" to create 
 * the countdown list.
 *
 * The function will accept a 
 * pointer to the array that will 
 * contain the 1-10 or 10-1 count, 
 * two pointers to the words 
 * "countdown" and "countup", and a 
 * flag to indicate if a countdown 
 * or a countup is to be created.
 *
 * Create a routine that will place 
 * the count into the passed array 
 * and then return a pointer to the 
 * word that describes the type of 
 * countdown / countup that has 
 * been created based on the 
 * variable flag 
 * (true = countdown, false = 
 * countup).
*/ 

#include <stdio.h>
#include <stdbool.h>

char *makeCounter(int *countHolder, char *downCount, char *upCount, bool flag){

  if(flag == true){
    downCount = (char*)malloc(10*sizeof(char));
    for (int i=0; i < 10; i++){
      downCount[i] = (countHolder[i]-47);
    }
      return downCount;
  }
  else {
    upCount = (char*)malloc(10*sizeof(char));
    for (int i=0; i < 10; i++){
      upCount[i] = (countHolder[9-i]-47);
  }
    return upCount;
  }
} 

int main(void) {
char ch;
int *array;
  
printf("Do you want to count up or down? U for up, D for down: ");
  scanf("%c", &ch);

  array = (int*)malloc(10*sizeof(int));
  for(int i=0; i<10; i++){
    array[i] = i+1;
  }

  char *downCount, *upCount;

  if (ch == 'u'){
    upCount = makeCounter(array, downCount, upCount, 1);

    printf("Count up: \n");
    for (int i=0; i < 10; i++){
      printf("%d\n", upCount[i]+47);
    }
  }
  else {
      downCount = makeCounter(array, downCount, upCount, 0);

    printf("Count down: \n");
    for (int i=0; i < 10; i++){
      printf("%d\n", downCount[i]+47);
    }
    
  }
  
  return 0;
}