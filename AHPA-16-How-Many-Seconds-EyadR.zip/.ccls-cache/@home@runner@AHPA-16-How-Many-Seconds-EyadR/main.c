/*
 * AHPA #16: How Many Seconds?
 *
 * Write the following function: 
 * void split_time(long total_sec, 
 * int *hr, int *min, int *sec);
 *
 * total_sec a time represented as 
 * the number of seconds since 
 * midnight. hr, min, and sec are 
 * pointers to variables in which 
 * the function will store the 
 * equivalent time in hours (0-12 + 
 * am/pm), minutes (0-59), and 
 * seconds (0-59), respectively.
 *
 * Example: 5:23.25pm = 
 *          62605 seconds
 * Returns: *hr = 5, *min = 23, 
 *          sec = 25
 */

#include <stdio.h>

void split_time(long total_sec, int *hr, int *min, int *sec){
  *hr = total_sec / 3600;
  total_sec -= *hr * 3600;
  *min = total_sec / 60;
  total_sec -=  *min * 60;
  *sec = total_sec; 
}

int main() {

 long total_sec = 45354; 
 int hour, min, sec;

  split_time(total_sec, &hour, &min, &sec);

  printf("Total elapsed time is %ld seconds\n\n", total_sec);
  printf("Split time is: \n Hours: %d, Minutes: %d, Seconds: %d\n", hour, min, sec);

  return 0;

}