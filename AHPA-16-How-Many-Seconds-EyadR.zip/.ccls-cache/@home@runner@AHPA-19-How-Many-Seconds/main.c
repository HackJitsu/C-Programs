/*
 * AHPA #19: How Many Seconds?
 *
 * Write the following function: 
 * void split_time(long total_sec, 
 * int *hr, int *min, int *sec);
 *
 * total_sec a time represented as 
 * the number of seconds since 
 * midnight. hr, min, and sec are 
 * pointers to variables in which 
 * the function will store the 
 * equivalent time in hours (0-12 + 
 * am/pm), minutes (0-59), and 
 * seconds (0-59), respectively.
 *
 * Example: 5:23.25pm = 
 *          62605 seconds
 * Returns: *hr = 5, *min = 23, 
 *          sec = 25
 */
  
#include <stdio.h>

int main(void) {
  
  return 0;
}