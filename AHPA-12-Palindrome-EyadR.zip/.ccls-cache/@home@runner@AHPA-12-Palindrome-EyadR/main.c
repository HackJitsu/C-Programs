/*
 * AHPA #12: Palindrome
 *
 * Write a C program that will ask 
 * the user for a number.
 *
 * The program will then check to 
 * see if the number is a 
 * palindrome.
 *
 * For example, 12321 is 
 * palindrome, but 1451 is not  
 * palindrome. 
 *
 * Student Name: Eyad Ramadan
 *
 */


#include <stdio.h>

int main(void) {
  int num, rev, sum=0,temp;
    printf("Enter a number to check if palindrome or not: ");
    scanf("%d", &num);
    temp = num;

  while(num>0){
      rev = num%10;
      sum = (sum*10)+rev;
      num = num/10;
    }
    if(temp == sum){
      printf("Yes, %d is a palindrome", temp);
      }
    else{
      printf("No, %d is not a palindrome", temp);
    }
  return 0;
}