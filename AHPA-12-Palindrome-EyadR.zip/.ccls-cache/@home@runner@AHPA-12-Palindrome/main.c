/*
 * AHPA #12: Palindrome
 *
 * Write a C program that will ask 
 * the user for a number.
 *
 * The program will then check to 
 * see if the number is a 
 * palindrome.
 *
 * For example, 12321 is 
 * palindrome, but 1451 is not  
 * palindrome. 
 *
 * Student Name:
 *
 */


#include <stdio.h>

int main(void) {
  
  return 0;
}