/*
 * AHPA #6:Multiplication Table
 */

#include <stdio.h>
#include <stdlib.h>

int main(void) {
    int i, j;
  
    for(i = 1; i <= 12; i++){
      for(j = 1; j <= 12; j++){
        int multiply = i * j;
        printf("%4d", multiply);

        if(j == 12){
          printf("\n");
        }
      }
    }
    printf("\n Lets play a guessing game, guess a number 1-10");
    printf("\n Enter your number: ");
   
  int userInput, number = 7;

    while(userInput != number){
      scanf("%d", &userInput);
      if (userInput > number){
        printf("Not it! Too high, try again: ");      
      }
      if(userInput < number){
        printf("Not it! Too low, Try again: ");
      }
      if(userInput == number){
        printf("Good job!! You guessed it!");
      }
      if(userInput > 10 | userInput < 1){
        printf("Also, that's not in the range!");
      }
  }
  return 0;
}