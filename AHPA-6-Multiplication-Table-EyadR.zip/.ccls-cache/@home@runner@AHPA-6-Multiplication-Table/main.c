/*
 * AHPA #6:Multiplication Table
 */

#include <stdio.h>

int main(void) {
  
  return 0;
}