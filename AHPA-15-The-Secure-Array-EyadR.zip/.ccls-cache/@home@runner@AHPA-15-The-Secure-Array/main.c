/*
 * The Secure Array
 *
 * Using pointers, access Peter's array without him knowing it 
 * and place three values that you got from the user (101, 63, 
 * 21) at locations 3, 6, and 9. Recalculate the sum value and 
 * update it.
 */

#include <stdio.h>

int main(void) {
  printf("Hello World\n");
  return 0;
}