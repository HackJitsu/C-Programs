/*
 * The Secure Array
 *
 * Using pointers, access Peter's array without him knowing it 
 * and place three values that you got from the user (101, 63, 
 * 21) at locations 3, 6, and 9. Recalculate the sum value and 
 * update it.
 */

#include <stdio.h>
#include <stdlib.h>

void printArray(int array[]){
  int arraySum = 0;

  printf("Peter's Array: \n");
  for(int i = 0; i<10; i++){
    printf("%d ", array[i]);
    arraySum += array[i];
  }
  printf("\n");
  printf("The sum of Peters array: %d\n", arraySum);
}
  
  
int main() {
  int peterArraySum;
  int peterArray[10] = {150, 130, 124, 115, 102, 101, 93, 84, 72, 63};
  printArray(peterArray);
  printf("\n");

  int n1,n2,n3;

  printf("Enter three numbers to be placed: \n");
  scanf("%d%d%d", &n1, &n2, &n3);
  *(peterArray+2) = n1;
  *(peterArray+5) = n2;
  *(peterArray+8) = n3;
  printArray(peterArray);
  
  
  return 0;
}