/*
 * AHPA #9: Ice Cream
 *
 * Bob’s Ice Cream sells ice cream 
 * from trucks that are parked at 
 * four different corners (A,B,C, 
 * and D). 
 *
 * They sold {$11,$15,$22,$7} on
 * Saturday and {$12,$9,$16,$21} on 
 * Sunday.
 *
 * Load a 2x4 array with Bob’s 
 * sales data.
 *
 * Sum the two matrices together.
 *
 * Tell Bob which one of his 
 * corners is selling the most ice 
 * cream:
 * The most sales were $x which was 
 * made on corner ?
 */

#include <stdio.h>

int main(void) {
  
  return 0;
}