/*
 * AHPA #9: Ice Cream
 *
 * Bob’s Ice Cream sells ice cream 
 * from trucks that are parked at 
 * four different corners (A,B,C, 
 * and D). 
 *
 * They sold {$11,$15,$22,$7} on
 * Saturday and {$12,$9,$16,$21} on 
 * Sunday.
 *
 * Load a 2x4 array with Bob’s 
 * sales data.
 *
 * Sum the two matrices together.
 *
 * Tell Bob which one of his 
 * corners is selling the most ice 
 * cream:
 * The most sales were $x which was 
 * made on corner ?
 */

#include <stdio.h>

int main(void) {
  //variables
  int i,j,sum,corner;
  //2x4 matrix with data
  int sales[2][4] = {
  {11,15,22,7},
  {12,9,16,21}
  };
  // storing maxium sales with variable
  int max = 0;
  //iterating on 4 corners
  for(i=0; i < 4; i++){
    sum =0;
  //add sales for saturday and sunday
  for (j=0; j < 2; j++){
    sum += sales[j][i];
  }
   // update max if sum is greater
  if(sum > max){
    max = sum;
    corner = 'A'+i;
  }
} 
  printf("The most sales were $%d which was made on corner %c", max, corner);
  return 0;
}