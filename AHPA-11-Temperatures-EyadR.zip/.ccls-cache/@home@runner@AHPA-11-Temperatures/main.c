/*
 * AHPA #11: Temperatures
 *
 * Create a program that will allow
 * a user to enter a temperature. 
 *
 * They can then ask for the 
 * temperature to be converted to 
 * either Celsius or Fahrenheit.
 */

#include <stdio.h>

int main(void) {
  printf("Hello World\n");
  return 0;
}