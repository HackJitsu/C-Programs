/*
 * AHPA #11: Temperatures
 *
 * Create a program that will allow
 * a user to enter a temperature. 
 *
 * They can then ask for the 
 * temperature to be converted to 
 * either Celsius or Fahrenheit.
 */

#include <stdio.h>

int celsiusToFarenheit(int num){
    int result;
  
    result = (num * 9) / 5.0 + 32;
    return result;
  }
 
int farenheitToCelsius(int num){
    int result;

    result = (num - 32) * 5 / 9.0;
    return result;
}
int main(void) {
  int userInput = 0;
  int userTemp = 0;
  int celsiusConvert = 0;
  int farenheitConvert = 0;
  printf("Hello! Enter 1 to convert from Celsius to Farenheit. Enter 2 to convert from Farenheit to Celsius: ");
  scanf("%d", &userInput);

  if(userInput > 2){
    printf("Error, incorrect input");
    return 0;
  }
   if(userInput < 1){
    printf("Error, incorrect input");
     return 0;
  }
   else{
    
  printf("Enter the temperature you want converted: ");
  scanf("%d", &userTemp);

  switch(userInput){
    case 1 :
   celsiusConvert = celsiusToFarenheit(userTemp);
    printf("%d", celsiusConvert);
      break;
    
    case 2 : 
   farenheitConvert = farenheitToCelsius(userTemp);
    printf("%d", farenheitConvert);
      break;  
    }
  }  
    return 0;
}